"""PocketSmart AI - FastAPI backend."""
import os, json, uuid, hashlib, secrets, hmac
from datetime import datetime, timedelta, timezone
import jwt
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form, File, UploadFile, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool
import gemini_utils as G

load_dotenv()
SECRET = os.getenv("SECRET_KEY") or secrets.token_hex(32)
EXPIRE_MIN = 60
DB_FILE = "data.json"
SESSIONS = {}
os.makedirs("static/uploads", exist_ok=True)
app = FastAPI(title="PocketSmart AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

def load():
    return json.load(open(DB_FILE)) if os.path.exists(DB_FILE) else {"users": {}, "history": {}}
def save(db):
    json.dump(db, open(DB_FILE, "w"), indent=1)
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()
def check_pw(pw, stored):
    return hmac.compare_digest(hash_pw(pw, stored.split("$")[0]), stored)
def token_for(u):
    return jwt.encode({"sub": u, "exp": datetime.now(timezone.utc) + timedelta(minutes=EXPIRE_MIN)}, SECRET, algorithm="HS256")
def current_user(request):
    try:
        u = jwt.decode(request.cookies.get("access_token", ""), SECRET, algorithms=["HS256"])["sub"]
        return u if u in load()["users"] else None
    except Exception:
        return None
def require(request):
    u = current_user(request)
    if not u:
        raise HTTPException(401, "Not authenticated")
    SESSIONS.setdefault(u, {"login_time": datetime.now().isoformat()})["last_activity"] = datetime.now().isoformat()
    return u
def login_response(u):
    r = RedirectResponse("/dashboard", 303)
    r.set_cookie("access_token", token_for(u), httponly=True, samesite="lax", max_age=EXPIRE_MIN * 60)
    SESSIONS[u] = {"login_time": datetime.now().isoformat(), "last_activity": datetime.now().isoformat()}
    return r
def record(u, kind, inp, res):
    db = load()
    db["history"].setdefault(u, []).append({"id": uuid.uuid4().hex, "timestamp": datetime.now().isoformat(timespec="seconds"),
                                            "type": kind, "input": inp, "result": res})
    save(db)
def page(request, name, **ctx):
    return templates.TemplateResponse(request, name, {"user": current_user(request), **ctx})
def budget_ok(d):
    try:
        if float(d.get("total_budget")) <= 0: raise ValueError
    except (TypeError, ValueError):
        raise HTTPException(422, "Enter a total budget greater than 0")

# ---------- pages ----------
@app.get("/")
async def index(request: Request): return page(request, "index.html")

@app.get("/login")
async def login_page(request: Request):
    return RedirectResponse("/dashboard") if current_user(request) else page(request, "auth.html", mode="login", error=None)

@app.get("/register")
async def register_page(request: Request):
    return RedirectResponse("/dashboard") if current_user(request) else page(request, "auth.html", mode="register", error=None)

@app.post("/register")
async def register(request: Request, username: str = Form(...), email: str = Form(...), password: str = Form(...), confirm: str = Form(...)):
    db, username = load(), username.strip()
    err = ("Username must be at least 3 characters" if len(username) < 3 else "Password must be at least 6 characters" if len(password) < 6
           else "Passwords do not match" if password != confirm else "Username already taken" if username in db["users"] else None)
    if err:
        return page(request, "auth.html", mode="register", error=err)
    db["users"][username] = {"email": email, "password": hash_pw(password)}
    save(db)
    return login_response(username)

@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    u = load()["users"].get(username.strip())
    if not u or not check_pw(password, u["password"]):
        return page(request, "auth.html", mode="login", error="Incorrect username or password")
    return login_response(username.strip())

@app.post("/token")
async def token(username: str = Form(...), password: str = Form(...)):
    u = load()["users"].get(username)
    if not u or not check_pw(password, u["password"]):
        raise HTTPException(401, "Incorrect username or password")
    return {"access_token": token_for(username), "token_type": "bearer"}

@app.api_route("/logout", methods=["GET", "POST"])
async def logout(request: Request):
    SESSIONS.pop(current_user(request), None)
    r = RedirectResponse("/login", 303)
    r.delete_cookie("access_token")
    return r

@app.get("/dashboard")
async def dashboard(request: Request):
    u = current_user(request)
    if not u: return RedirectResponse("/login")
    return page(request, "dashboard.html", recent=list(reversed(load()["history"].get(u, [])))[:4])

@app.get("/{kind}-planner")
async def planner(request: Request, kind: str):
    if kind not in ("home", "party", "jewelry"): raise HTTPException(404)
    if not current_user(request): return RedirectResponse("/login")
    return page(request, "planner.html", kind=kind)

@app.get("/history")
async def history_page(request: Request):
    return page(request, "history.html") if current_user(request) else RedirectResponse("/login")

# ---------- recommendation APIs ----------
@app.post("/home-budget")
@app.post("/generate-home")
async def home_budget(request: Request):
    u, d = require(request), await request.json()
    budget_ok(d)
    res = await run_in_threadpool(G.home_recommendations, d)
    record(u, "home", d, res)
    return res

@app.post("/party-budget")
@app.post("/generate-party")
async def party_budget(request: Request):
    u, d = require(request), await request.json()
    budget_ok(d)
    res = await run_in_threadpool(G.party_recommendations, d)
    record(u, "party", d, res)
    return res

@app.post("/jewelry-budget")
@app.post("/generate-jewelry")
async def jewelry_budget(request: Request, total_budget: float = Form(...), occasion: str = Form(...),
                         preferences: str = Form(""), image: UploadFile = File(None)):
    u = require(request)
    d = {"total_budget": total_budget, "occasion": occasion, "preferences": preferences}
    budget_ok(d)
    path = None
    if image and image.filename:
        ext = os.path.splitext(image.filename)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".webp"):
            raise HTTPException(422, "Upload a JPG, PNG or WEBP image")
        path = f"static/uploads/{uuid.uuid4().hex}{ext}"
        with open(path, "wb") as f: f.write(await image.read())
        d["image"] = image.filename
    res = await run_in_threadpool(G.jewelry_recommendations, d, path)
    record(u, "jewelry", d, res)
    return res

@app.get("/recommendation-history")
async def rec_history(request: Request):
    u = require(request)
    return {"history": [{k: h[k] for k in ("id", "timestamp", "type", "input")} | {"total_budget": h["result"].get("total_budget"),
            "remaining_budget": h["result"].get("remaining_budget")} for h in reversed(load()["history"].get(u, []))]}

@app.get("/recommendation-details/{rid}")
async def rec_details(request: Request, rid: str):
    for h in load()["history"].get(require(request), []):
        if h["id"] == rid: return h
    raise HTTPException(404, "Recommendation not found")

@app.get("/session-info")
async def session_info(request: Request):
    u = require(request)
    return {"username": u, **SESSIONS[u]}

if __name__ == "__main__":
    import uvicorn
    print("Starting PocketSmart AI on http://localhost:8000")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
