# PocketSmart AI
1. python -m venv venv ; activate it
2. pip install -r requirements.txt
3. copy .env.example to .env and add GOOGLE_API_KEY
4. python main.py  ->  http://localhost:8000
Without an API key the app still works using default (fallback) recommendations.
