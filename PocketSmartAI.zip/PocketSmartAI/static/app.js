const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inr=n=>"₹"+Number(n||0).toLocaleString("en-IN");
const chips=l=>Object.entries(l||{}).map(([k,u])=>`<a class="chip" target="_blank" rel="noopener" href="${esc(u)}">${esc(k)}</a>`).join("");
const item=i=>`<div class="item"><div><b>${esc(i.name||i.item_type)}</b>${i.quantity>1?" × "+i.quantity:""}<p>${esc(i.description)}</p>${chips(i.shopping_links)}</div><span class="price">${inr(i.estimated_price)}</span></div>`;
function renderResult(r){
  let h=`<div class="card"><h2>Your plan</h2><p>Budget <b>${inr(r.total_budget)}</b> · Remaining <b>${inr(r.remaining_budget)}</b> <small>(${r.source==="gemini"?"Gemini AI":"default suggestions"})</small></p>${r.note?`<p class="warn">Gemini was unavailable, so default suggestions are shown: ${esc(r.note)}</p>`:""}</div>`;
  const o=r.outfit_analysis; if(o) h+=`<div class="card"><b>Outfit analysis</b><p>Colours: ${esc((o.colors||[]).join(", "))} · Style: ${esc(o.style)} · Formality: ${esc(o.formality)}</p></div>`;
  (r.budget_breakdown||[]).forEach(c=>{h+=`<div class="card"><div class="cat"><span>${esc(String(c.category).replace("_"," "))}</span><span>${inr(c.allocation)}</span></div>${(c.items||[]).map(item).join("")}</div>`});
  if(r.jewelry_recommendations) h+=`<div class="card">${r.jewelry_recommendations.map(item).join("")}</div>`;
  const tips=[...(r.additional_suggestions||[]),...(r.styling_tips||[])];
  if(tips.length) h+=`<div class="card"><b>Tips</b><ul>${tips.map(t=>`<li>${esc(t)}</li>`).join("")}</ul></div>`;
  return h;
}
async function runPlanner(form){
  const out=document.getElementById("result"),btn=document.getElementById("go");
  btn.disabled=true;btn.textContent="Thinking...";out.innerHTML="";
  try{
    let opts={method:"POST"};
    if(form.dataset.multipart){opts.body=new FormData(form);}
    else{const d={};[...form.elements].forEach(e=>{if(!e.name)return;d[e.name]=e.type==="checkbox"?e.checked:e.type==="number"?parseFloat(e.value)||0:e.value});
      opts.headers={"Content-Type":"application/json"};opts.body=JSON.stringify(d);}
    const res=await fetch(form.dataset.url,opts),data=await res.json();
    if(res.status===401){location="/login";return}
    if(!res.ok)throw new Error(typeof data.detail==="string"?data.detail:"Please check your inputs");
    out.innerHTML=renderResult(data);out.scrollIntoView({behavior:"smooth"});
  }catch(e){out.innerHTML=`<p class="warn">${esc(e.message)}</p>`}
  btn.disabled=false;btn.textContent="Generate recommendations";
}
async function loadHistory(box){
  const res=await fetch("/recommendation-history");if(!res.ok){location="/login";return}
  const {history}=await res.json();
  box.innerHTML=history.length?history.map(h=>`<div class="card"><b>${esc(h.type)} plan</b><p class="muted">${esc(h.timestamp)}<br>Budget ${inr(h.total_budget)} · Remaining ${inr(h.remaining_budget)}</p><button class="btn small" data-id="${h.id}">View details</button></div>`).join(""):"<p class='muted'>No plans yet. Create one from a planner.</p>";
  box.onclick=async e=>{const id=e.target.dataset.id;if(!id)return;const d=await (await fetch("/recommendation-details/"+id)).json();
    const r=document.getElementById("result");r.innerHTML=renderResult(d.result);r.scrollIntoView({behavior:"smooth"})};
}
document.addEventListener("DOMContentLoaded",()=>{
  const f=document.getElementById("planner");if(f)f.addEventListener("submit",e=>{e.preventDefault();runPlanner(f)});
  const h=document.getElementById("history");if(h)loadHistory(h);
});
