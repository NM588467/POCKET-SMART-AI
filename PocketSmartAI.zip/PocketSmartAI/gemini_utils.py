"""Gemini prompt orchestration, link building and fallbacks."""
import os, json, re
from urllib.parse import quote_plus
from dotenv import load_dotenv
load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

LINKS = {
    "amazon": "https://www.amazon.in/s?k=", "flipkart": "https://www.flipkart.com/search?q=",
    "ikea": "https://www.ikea.com/in/en/search/?q=", "swiggy": "https://www.swiggy.com/search?query=",
    "zomato": "https://www.zomato.com/search?q=", "bookmyshow": "https://in.bookmyshow.com/search?q=",
    "oyo": "https://www.oyorooms.com/search/?location=", "google": "https://www.google.com/search?q=",
    "bluestone": "https://www.bluestone.com/search.html?query=", "tanishq": "https://www.tanishq.co.in/search?q=",
    "caratlane": "https://www.caratlane.com/search?q=",
}
PLATFORMS = {
    "home": ["amazon", "flipkart", "ikea"],
    "party": {"venue": ["oyo", "google"], "catering": ["swiggy", "zomato"], "food": ["swiggy", "zomato"],
              "entertainment": ["bookmyshow", "amazon"], "decoration": ["amazon", "flipkart"]},
    "jewelry": ["amazon", "flipkart", "bluestone", "tanishq", "caratlane"],
}

def extract_json(text):
    text = re.sub(r"```(?:json)?", "", text or "").strip()
    return json.loads(text[text.index("{"): text.rindex("}") + 1])

def ask(prompt, image_path=None):
    if not API_KEY:
        raise RuntimeError("No GOOGLE_API_KEY set")
    import google.generativeai as genai
    genai.configure(api_key=API_KEY)
    model = genai.GenerativeModel(MODEL, generation_config={"response_mime_type": "application/json", "temperature": 0.4})
    parts = [prompt]
    if image_path:
        from PIL import Image
        parts.append(Image.open(image_path))
    return extract_json(model.generate_content(parts).text)

def _links(kind, cat, terms):
    p = PLATFORMS[kind]
    if isinstance(p, dict):
        p = p.get(cat.lower(), ["amazon", "flipkart", "google"])
    return {k: LINKS[k] + quote_plus(terms) for k in p}

def _finish(r, budget, kind, key):
    r["total_budget"] = budget
    spent = 0
    for c in r.get(key, []) if key == "budget_breakdown" else [{"category": "jewelry", "items": r.get(key, [])}]:
        for i in c.get("items", []):
            i["quantity"] = i.get("quantity") or 1
            i["estimated_price"] = float(i.get("estimated_price") or 0)
            spent += i["estimated_price"] * (i["quantity"] if key == "budget_breakdown" else 1)
            i["shopping_links"] = _links(kind, c.get("category", ""), i.get("search_terms") or i.get("name") or i.get("item_type") or "")
    r["remaining_budget"] = round(budget - spent, 2)
    r.setdefault("additional_suggestions", r.pop("styling_tips", []) if kind == "jewelry" else [])
    if kind == "jewelry":
        r["styling_tips"] = r.pop("additional_suggestions")
    return r

def _run(prompt, fallback, budget, kind, key, image_path=None):
    try:
        r = ask(prompt, image_path)
        if not r.get(key):
            raise ValueError("Gemini returned no recommendations")
        r["source"] = "gemini"
    except Exception as e:  # Activity 5.4: fallback recommendations
        r = fallback()
        r["source"], r["note"] = "fallback", str(e)[:160]
    return _finish(r, budget, kind, key)

def _fb(budget, split):
    bd = []
    for cat, (w, name) in split.items():
        amt = round(budget * w, 2)
        bd.append({"category": cat, "allocation": amt, "items": [{"name": name, "description": "Default budget-friendly suggestion",
                   "estimated_price": amt, "quantity": 1, "search_terms": name}]})
    return {"budget_breakdown": bd, "additional_suggestions": ["Compare prices across platforms.", "Watch for seasonal sales."]}

BREAKDOWN = ('{"budget_breakdown":[{"category":"","allocation":0,"items":[{"name":"","description":"",'
             '"estimated_price":0,"quantity":1,"search_terms":""}]}],"additional_suggestions":[""]}')

def home_recommendations(d):
    b = float(d["total_budget"])
    rooms = [r for r, k in (("Living room", "has_living_room"), ("Kitchen", "has_kitchen"), ("Bedroom", "has_bedroom")) if d.get(k)]
    prompt = (f"Interior design recommendations for a home in India, total budget INR {b:.0f}. Need {d.get('num_lights',0)} lights, "
              f"{d.get('num_fans',0)} ceiling fans, {d.get('num_furniture',0)} furniture pieces, {d.get('num_dining_tables',0)} dining tables. "
              f"Rooms: {', '.join(rooms) or 'any'}. Extra: {d.get('additional_requirements') or 'None'}. Use Indian brands and INR prices "
              f"(estimated_price is per unit). Total must not exceed budget. Categories: lighting, ceiling_fans, furniture. "
              f"Search terms should suit Amazon India, Flipkart, IKEA. Reply ONLY JSON like: {BREAKDOWN}")
    fb = lambda: _fb(b, {"lighting": (.25, f"{d.get('num_lights',0)} LED light fixtures"), "ceiling_fans": (.3, f"{d.get('num_fans',0)} BLDC ceiling fans"),
                         "furniture": (.3, f"{d.get('num_furniture',0)} furniture pieces"), "dining": (.15, "dining table")})
    return _run(prompt, fb, b, "home", "budget_breakdown")

def party_recommendations(d):
    b = float(d["total_budget"])
    needs = [n for n in ("catering", "decoration", "entertainment") if d.get(f"needs_{n}")]
    prompt = (f"Party plan in India, total budget INR {b:.0f}. Type: {d.get('party_type')}, guests: {d.get('num_guests')}, venue: {d.get('venue_type') or 'unspecified'}. "
              f"Needs: {', '.join(needs) or 'venue only'}. Extra: {d.get('additional_requirements') or 'None'}. Allocate budget proportionally; "
              f"categories from venue, catering, decoration, entertainment, contingency. INR only, total within budget. "
              f"estimated_price is per line item total, quantity 1. Reply ONLY JSON like: {BREAKDOWN}")
    split = {"venue": (.2, f"{d.get('venue_type') or 'venue'} booking")}
    w = .8 / max(len(needs), 1)
    for n in needs:
        split[n] = (w * .9, f"{d.get('party_type')} {n} for {d.get('num_guests')} guests")
    split["contingency"] = (.08 if needs else 0, "contingency buffer")
    return _run(prompt, lambda: _fb(b, split), b, "party", "budget_breakdown")

def jewelry_recommendations(d, image_path=None):
    b = float(d["total_budget"])
    prompt = (f"Jewelry recommendations for India, budget INR {b:.0f}. Occasion: {d.get('occasion')}. Preferences: {d.get('preferences') or 'none'}. "
              + ("An outfit image is attached: analyse colours, style, formality and match jewelry to it. " if image_path else "")
              + 'INR prices within budget. Reply ONLY JSON: {"outfit_analysis":{"colors":[],"style":"","formality":""},'
              '"jewelry_recommendations":[{"item_type":"","description":"","style":"","estimated_price":0,"search_terms":""}],"styling_tips":[""]}')
    def fb():
        return {"jewelry_recommendations": [{"item_type": t, "description": f"Elegant {t} for a {d.get('occasion')}", "style": "classic",
                "estimated_price": round(b * w, 2), "search_terms": f"{t} for women {d.get('occasion')}"}
                for t, w in (("earrings", .3), ("necklace", .4), ("bracelet", .2))], "styling_tips": ["Keep metal tones consistent."]}
    return _run(prompt, fb, b, "jewelry", "jewelry_recommendations", image_path)
